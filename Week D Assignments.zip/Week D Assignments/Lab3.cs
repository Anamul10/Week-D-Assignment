using System;
class HelloWorld {
    public static double transaction(double bal, double amount)
    {
        if(amount > 0)
        {
            bal+=amount;
        }
        else
        {
            if((amount*(-1) > bal))
                bal -= bal;
            else
                bal -= amount;
        }
        return bal;
    }
  static void Main() {
    double currBal = 45.32;
    double amount;
    Console.Write("Please Enter amount to be updated in the account : ");
    string num = Console.ReadLine();
    amount = double.Parse(num);
    Console.Write("\nCustomer\'s balance (before transaction) = $ " + currBal + "\n");
    Console.Write("Request updated amount = $" + amount);
    double actamount;
    actamount = transaction(currBal, amount);
    currBal += actamount;
    Console.Write("\nActual update amount = $" + actamount + "\n");
    Console.Write("Customer's balance after (after transaction) = $" + currBal + "\n");
    Console.Write("Thank you for and good-bye.");
  }
}