using System;
/*
Questions.
Question1:
Answer: Yes we need int parameters so that it can handle values with the int type values.
Question2:
Answer: Yes we need 3 parameters version of the average function to handle 3 parameters at a time and no these 2 function are not equal.
Question3:
Answer: Yes, it is legal because int values can be treated as double in the function and average(double,double, double);


*/

class HelloWorld {
    public static double average(int num1, int num2)
    {
        
        return (num1+num2)/2.0;
    }
    public static double average(int num1, int num2, int num3)
    {
        
        return (num1+num2+num3)/3.0;
    }
    public static double average(double num1, double num2)
    {
        
        return (num1+num2)/2.0;
    }
    public static double average(double num1, double num2, double num3)
    {
        
        return (num1+num2+num3)/3.0;
    }
    
  static void Main() {
    int a = 1, b = 3, c = 5;
    double x=2.2, y = 4.4, z = 6.6, ans;
    ans = average(a, b);
    Console.Write("\nAverage(a, b) = " + ans);
    ans = average(a, b, c);
    Console.Write("\naverage(a, b, c) = " + ans);
    ans = average(x, y);
    Console.Write("\naverage(x, y) = " + ans);
    ans = average(x, y, z);
    Console.Write("\naverage(x, y, z) = " + ans);
    
    
  }
}